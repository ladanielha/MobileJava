package id.ac.umn.music;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.io.File;

public class Home extends AppCompatActivity {
    private static final int PERMISSION_REQ = 1;
    EditText etSearch;
    ArrayList<String> arrayList;
    ListView list_music;
    ArrayAdapter<String> adapter;
    ArrayList<DataLagu> songDetails = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(ContextCompat.checkSelfPermission(Home .this,Manifest.permission.READ_EXTERNAL_STORAGE)!=
                PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(Home.this,
                    Manifest.permission.READ_EXTERNAL_STORAGE)) {
                ActivityCompat.requestPermissions(Home.this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, PERMISSION_REQ);
            } else {
                ActivityCompat.requestPermissions(Home.this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, PERMISSION_REQ);
            }
        }
        else{
            apaSihwkwkwk();
        }

        OpenDialog();
    }

    public void apaSihwkwkwk(){
        list_music = findViewById(R.id.daftarmusic);

        arrayList = new ArrayList<>();
        getMusic();

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, arrayList);
        list_music.setAdapter(adapter);


        list_music.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String dir="";
                String judul="";
                String artist="";
                for(int i =0;i<songDetails.size();i++)
                {
                    if (songDetails.get(i).getTitle() == parent.getItemAtPosition(position)){
                        dir = songDetails.get(i).getCurrDir();
                        judul = songDetails.get(i).getTitle();
                        artist = songDetails.get(i).getCurrArtist();
                        break;

                    }
                }
                Intent intent = new Intent(getApplicationContext(),Playing.class);
                intent.putExtra("judul",judul).putExtra("artist",artist).putExtra("dir",dir);
                startActivity(intent);
            }
        });

    }

    public void getMusic(){
        ContentResolver contentResolver = getContentResolver();
        Uri musicUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        Cursor musicCursor = contentResolver.query(musicUri, null, null, null, null);

        if (musicCursor != null && musicCursor.moveToFirst()){
            int musicTitle = musicCursor.getColumnIndex(MediaStore.Audio.Media.TITLE);
            int musicArtist = musicCursor.getColumnIndex(MediaStore.Audio.Media.ARTIST);
            int musicDir = musicCursor.getColumnIndex(MediaStore.Audio.Media.DATA);
            do {
                String currTitle = musicCursor.getString(musicTitle);
                String currArtist = musicCursor.getString(musicArtist);
                String currDir = musicCursor.getString(musicDir);
                songDetails.add(new DataLagu(currTitle,currArtist,currDir));
                arrayList.add(currTitle);
            }while (musicCursor.moveToNext());
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode)
        {
            case PERMISSION_REQ: {
                if (grantResults.length>0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    if (ContextCompat.checkSelfPermission(Home.this,
                            Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED){
                        Toast.makeText(this, "Permission granted", Toast.LENGTH_SHORT).show();
                        apaSihwkwkwk();
                    }
                } else{
                    Toast.makeText(this,"No Permission Granted",Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        }
    }

    public void OpenDialog(){
        DialogueClass dialogueClass = new DialogueClass();
        dialogueClass.show(getSupportFragmentManager(),"dialogue class");
    }
}
