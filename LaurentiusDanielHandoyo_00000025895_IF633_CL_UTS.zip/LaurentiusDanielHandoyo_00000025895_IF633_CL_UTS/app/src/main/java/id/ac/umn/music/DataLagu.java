package id.ac.umn.music;

class DataLagu {
    private String current_Title;
    private String current_Artist;
    private String current_Dir;
    DataLagu(String current_Title, String current_Artist, String current_Dir){
        this.current_Title = current_Title;
        this.current_Artist = current_Artist;
        this.current_Dir = current_Dir;
    }

    String getTitle(){
        return current_Title;
    }
    String getCurrArtist(){
        return current_Artist;
    }
    String getCurrDir(){
        return current_Dir;
    }
}